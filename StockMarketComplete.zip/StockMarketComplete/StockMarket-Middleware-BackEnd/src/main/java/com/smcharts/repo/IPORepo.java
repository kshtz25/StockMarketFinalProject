package com.smcharts.repo;

import org.springframework.data.repository.CrudRepository;

import com.smcharts.model.IPO;

public interface IPORepo extends CrudRepository<IPO, Long>{

}
